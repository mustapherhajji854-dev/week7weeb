# SpendWise – Personal Finance Dashboard

## Project Description
SpendWise is a responsive personal finance dashboard designed to help users view their balance, monitor income and expenses, follow a monthly budget, and review recent transactions. The demo includes an interactive transaction form and stores transactions in the browser using localStorage.

## Technologies Used
- HTML5 – page structure and semantic content
- CSS3 – responsive layout, styling, Grid and Flexbox
- JavaScript – interface interactions, transaction handling and local storage
- Chart.js – spending overview chart
- Git and GitHub – source-code version control and repository hosting
- Netlify – website deployment and continuous deployment

## GitHub Repository Information
- Repository name: `spendwise-dashboard`
- Repository visibility: Public
- Main branch: `main`
- Repository URL: **ADD YOUR PUBLIC GITHUB REPOSITORY URL HERE**

## Live Netlify Website URL
**ADD YOUR LIVE NETLIFY URL HERE AFTER DEPLOYMENT.**

## Deployment Process Summary
1. Reviewed the project files and confirmed that `index.html`, `style.css`, `app.js`, and `netlify.toml` are included.
2. Created a public GitHub repository named `spendwise-dashboard`.
3. Uploaded the complete project to the repository's `main` branch.
4. Signed in to Netlify and selected the option to import an existing project from Git.
5. Connected the GitHub account and selected the `spendwise-dashboard` repository.
6. Configured the publish directory as `.` because this is a static HTML, CSS and JavaScript project. No build command is required.
7. Deployed the website and changed the default Netlify site name to a SpendWise-related name.
8. Copied the live Netlify URL into this README.
9. Tested the deployed site on desktop and mobile screen sizes.
10. Updated a visible item in the project, committed and pushed the change to GitHub, then confirmed that Netlify started and completed a new deployment.

## Challenges Encountered During Deployment
- Ensuring that all project files were included in the GitHub repository.
- Selecting the correct publish directory in Netlify for a static website.
- Checking that file names and paths use the correct spelling and letter case.
- Verifying that the latest GitHub commit was reflected on the live Netlify website.

*Edit this section to describe the actual challenges you encountered. Remove any item that did not happen.*

## Lessons Learned
- GitHub provides a reliable place to store and manage project source code.
- Netlify can deploy a static website directly from a GitHub repository.
- Continuous deployment makes it easier to publish updates after pushing commits.
- Responsive design helps a website work on different screen sizes.
- Testing the live website is important because a successful deployment does not automatically guarantee that every feature works correctly.

## Local Preview
Open `index.html` in a web browser. An internet connection is needed to load the Google Fonts and Chart.js CDN resources.

## Project Structure
```text
SpendWise/
├── index.html
├── style.css
├── app.js
├── netlify.toml
└── README.md
```

## Author
SpendWise student deployment assignment – 2026.
