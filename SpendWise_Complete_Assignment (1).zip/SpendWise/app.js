document.addEventListener("DOMContentLoaded", () => {
  const $ = (selector) => document.querySelector(selector);
  const money = (amount) => "KSh " + Number(amount).toLocaleString("en-KE");
  $("#todayLabel").textContent = new Date().toLocaleDateString("en-KE", {weekday:"short", day:"numeric", month:"short", year:"numeric"});

  const navLinks = document.querySelectorAll(".nav-link");
  navLinks.forEach(link => link.addEventListener("click", () => {
    navLinks.forEach(item => item.classList.remove("active"));
    link.classList.add("active");
    $("#pageName").textContent = link.textContent.trim();
    $("#sidebar").classList.remove("open");
  }));
  $("#menuToggle").addEventListener("click", () => $("#sidebar").classList.toggle("open"));

  let transactions = [];
  try { transactions = JSON.parse(localStorage.getItem("spendwiseTransactions") || "[]"); } catch { transactions = []; }

  function renderTransactions() {
    const tbody = $("#transactionRows");
    tbody.querySelectorAll("[data-custom='true']").forEach(row => row.remove());
    transactions.slice().reverse().forEach(item => {
      const row = document.createElement("tr");
      row.dataset.custom = "true";
      const sign = item.type === "income" ? "+" : "−";
      const amountClass = item.type === "income" ? "income" : "expense";
      const iconClass = item.type === "income" ? "salary" : "grocery";
      const date = new Date(item.date).toLocaleDateString("en-KE", {day:"numeric", month:"short", year:"numeric"});
      row.innerHTML = `<td><span class="merchant-icon ${iconClass}">${item.name.charAt(0).toUpperCase()}</span><span class="merchant-name"></span></td><td></td><td></td><td class="amount ${amountClass}"></td><td><span class="status paid">Completed</span></td>`;
      row.querySelector(".merchant-name").textContent = item.name;
      row.children[1].textContent = item.category;
      row.children[2].textContent = date;
      row.children[3].textContent = `${sign} ${money(item.amount)}`;
      tbody.appendChild(row);
    });
    $("#emptyState").hidden = transactions.length > 0;
  }

  const dialog = $("#transactionDialog");
  $("#addTransactionBtn").addEventListener("click", () => dialog.showModal());
  $("#transactionForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const item = {
      name: String(data.get("name")).trim(),
      amount: Number(data.get("amount")),
      type: String(data.get("type")),
      category: String(data.get("category")),
      date: new Date().toISOString()
    };
    if (!item.name || !Number.isFinite(item.amount) || item.amount <= 0) return;
    transactions.push(item);
    localStorage.setItem("spendwiseTransactions", JSON.stringify(transactions));
    renderTransactions();
    form.reset();
    dialog.close();
  });
  $("#viewAllBtn").addEventListener("click", () => {
    $("#transactions").scrollIntoView({behavior:"smooth"});
    $("#pageName").textContent = "Transactions";
  });
  $("#budgetInfo").addEventListener("click", () => alert("Your monthly budget is KSh 50,000. You have KSh 14,250 remaining in this demo."));
  $("#periodSelect").addEventListener("change", (event) => {
    const isWeek = event.target.value === "week";
    spendingChart.data.labels = isWeek ? ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"] : ["Week 1","Week 2","Week 3","Week 4"];
    spendingChart.data.datasets[0].data = isWeek ? [12000,9000,14000,11000,16000,8000,10000] : [28000,32000,25000,35000];
    spendingChart.data.datasets[1].data = isWeek ? [5000,7000,4500,8000,6000,3500,5000] : [9000,11000,7000,8750];
    spendingChart.update();
  });

  const ctx = $("#spendingChart").getContext("2d");
  const spendingChart = new Chart(ctx, {
    type:"bar",
    data:{
      labels:["Week 1","Week 2","Week 3","Week 4"],
      datasets:[
        {label:"Income",data:[28000,32000,25000,35000],backgroundColor:"#16845d",borderRadius:5,barThickness:12},
        {label:"Expenses",data:[9000,11000,7000,8750],backgroundColor:"#e8b95d",borderRadius:5,barThickness:12}
      ]
    },
    options:{
      responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false},tooltip:{callbacks:{label:(context)=>`${context.dataset.label}: ${money(context.raw)}`}}},
      scales:{
        x:{grid:{display:false},ticks:{color:"#98a49d",font:{family:"DM Sans",size:10}},border:{display:false}},
        y:{beginAtZero:true,grid:{color:"#eff2f0"},ticks:{color:"#a0aaa5",font:{family:"DM Sans",size:9},callback:(value)=>`${value/1000}k`},border:{display:false}}
      }
    }
  });
  renderTransactions();
});